import React from 'react'

export default function ListWrapper(props){
    return (<div className='container'>{props.children}</div>)
}